extends Node
## Saltmire Impact — the one-call game-feel orchestrator for Godot 4.
## Combines screen shake, hit-stop (with curves), flash, damage numbers and
## sprite shader effects into single, tunable "combo" calls. Autoloaded as
## `Impact`. Self-contained: no other Saltmire plugin required.
##
## https://saltmire.itch.io  ·  Commercial license (see LICENSE.txt)
##
## The one-liners you actually want:
##   Impact.hit(enemy_sprite, camera, 12)          # flash + shake + number
##   await Impact.crit(enemy_sprite, camera, 30)   # bigger + hit-stop freeze
##   Impact.explode(sprite, camera)                # dissolve + big shake
##   Impact.combo(camera, count)                   # scaling combo feedback
##
## Every primitive is also exposed directly (shake/hitstop/flash/pop/
## damage_number + dissolve/appear/outline/freeze/hologram/clear) so you can
## assemble your own recipes. Tunables live in the `cfg` dictionary below.

const DamageNumber := preload("res://addons/saltmire_impact/damage_number.gd")

const DISSOLVE := preload("res://addons/saltmire_impact/shaders/dissolve.gdshader")
const OUTLINE := preload("res://addons/saltmire_impact/shaders/outline.gdshader")
const HIT_FLASH := preload("res://addons/saltmire_impact/shaders/hit_flash.gdshader")
const FREEZE := preload("res://addons/saltmire_impact/shaders/freeze.gdshader")
const HOLOGRAM := preload("res://addons/saltmire_impact/shaders/hologram.gdshader")

## Global feel tuning — tweak once, every combo respects it.
var cfg := {
	"shake_hit": 0.35,
	"shake_crit": 0.7,
	"shake_explode": 0.9,
	"hitstop_crit": 0.09,
	"hitstop_scale": 0.05,   # near-freeze time_scale during crit
	"flash_color": Color(4, 4, 4, 1),
	"crit_color": Color(1.0, 0.85, 0.2),
	"number_color": Color(1, 1, 1),
	"crit_number_color": Color(1.0, 0.8, 0.15),
}

# ===========================================================================
# COMBO PRESETS  (the paid convenience layer — one call = full impact)
# ===========================================================================

## Standard hit: white flash + small shake + a rising damage number.
func hit(sprite: CanvasItem, camera: Camera2D, value: Variant = null,
		world_pos: Variant = null) -> void:
	if sprite != null:
		flash(sprite, cfg.flash_color, 0.12)
		pop(sprite, 1.12, 0.14)
	shake(camera, cfg.shake_hit)
	if value != null:
		damage_number(_number_parent(sprite, camera), _pos(sprite, world_pos), value,
			{"color": cfg.number_color})

## Critical hit: golden flash + big shake + hit-stop freeze + punchy number.
## `await` it if you want gameplay to resume only after the freeze.
func crit(sprite: CanvasItem, camera: Camera2D, value: Variant = null,
		world_pos: Variant = null) -> void:
	if sprite != null:
		flash(sprite, cfg.crit_color * 4.0, 0.16)
		pop(sprite, 1.3, 0.22)
	shake(camera, cfg.shake_crit)
	if value != null:
		damage_number(_number_parent(sprite, camera), _pos(sprite, world_pos), value,
			{"color": cfg.crit_number_color, "scale": 1.5, "rise": 48.0})
	await hitstop_curve(cfg.hitstop_crit, cfg.hitstop_scale)

## Explosion / death: dissolve the sprite away + heavy shake.
func explode(sprite: CanvasItem, camera: Camera2D, duration: float = 0.45) -> void:
	shake(camera, cfg.shake_explode)
	if sprite != null:
		flash(sprite, cfg.flash_color, 0.1)
		dissolve(sprite, duration)

## Combo counter feedback — intensity scales with `count` and saturates.
## Great to call every time a combo increments.
func combo(camera: Camera2D, count: int) -> void:
	var t := clampf(float(count) / 20.0, 0.05, 1.0)
	shake(camera, lerpf(0.12, 0.6, t))

# ===========================================================================
# HIT-STOP  (PRO: eased ramp back to normal speed instead of a hard snap)
# ===========================================================================
var _hitstop_token := 0

## Classic hard hit-stop: freeze then instantly resume.
func hitstop(duration: float = 0.08, time_scale: float = 0.0) -> void:
	_hitstop_token += 1
	var token := _hitstop_token
	Engine.time_scale = time_scale
	await get_tree().create_timer(duration, true, false, true).timeout
	if token == _hitstop_token:
		Engine.time_scale = 1.0

## PRO hit-stop: hold at `time_scale`, then EASE back to 1.0 over `ramp`
## seconds for a much smoother, weightier impact. Nested calls are safe.
func hitstop_curve(duration: float = 0.08, time_scale: float = 0.05,
		ramp: float = 0.12) -> void:
	_hitstop_token += 1
	var token := _hitstop_token
	Engine.time_scale = time_scale
	await get_tree().create_timer(duration, true, false, true).timeout
	if token != _hitstop_token:
		return
	var elapsed := 0.0
	while elapsed < ramp:
		await get_tree().create_timer(0.016, true, false, true).timeout
		if token != _hitstop_token:
			return
		elapsed += 0.016
		var k := clampf(elapsed / ramp, 0.0, 1.0)
		Engine.time_scale = lerpf(time_scale, 1.0, ease(k, 0.4))
	if token == _hitstop_token:
		Engine.time_scale = 1.0

# ===========================================================================
# SCREEN SHAKE  (trauma-based; trauma^2 so small hits stay subtle)
# ===========================================================================
var _shakes: Dictionary = {}

func shake(camera: Camera2D, amount: float = 0.5, decay: float = 1.4,
		max_offset: Vector2 = Vector2(22, 14), max_roll: float = 0.08) -> void:
	if camera == null:
		return
	var s: Dictionary = _shakes.get(camera, {"trauma": 0.0})
	s.trauma = minf(1.0, float(s.get("trauma", 0.0)) + amount)
	s.decay = decay
	s.max_offset = max_offset
	s.max_roll = max_roll
	_shakes[camera] = s
	set_process(true)

func _process(delta: float) -> void:
	if _shakes.is_empty():
		set_process(false)
		return
	for cam in _shakes.keys():
		if not is_instance_valid(cam):
			_shakes.erase(cam)
			continue
		var s: Dictionary = _shakes[cam]
		s.trauma = maxf(0.0, s.trauma - s.decay * delta)
		var amt: float = s.trauma * s.trauma
		if s.trauma <= 0.0:
			cam.offset = Vector2.ZERO
			cam.rotation = 0.0
			_shakes.erase(cam)
		else:
			cam.offset = Vector2(randf_range(-1.0, 1.0) * s.max_offset.x,
								 randf_range(-1.0, 1.0) * s.max_offset.y) * amt
			cam.rotation = randf_range(-1.0, 1.0) * s.max_roll * amt

# ===========================================================================
# FLASH & POP
# ===========================================================================
func flash(target: CanvasItem, color: Color = Color(4, 4, 4, 1),
		duration: float = 0.15, back_to: Color = Color(1, 1, 1, 1)) -> void:
	if target == null:
		return
	target.modulate = color
	var t := target.create_tween()
	t.tween_property(target, "modulate", back_to, duration)

func pop(node: Node, scale_mult: float = 1.25, duration: float = 0.18) -> void:
	if node == null or not ("scale" in node):
		return
	var base: Vector2 = node.scale
	node.scale = base * scale_mult
	var t := node.create_tween()
	t.tween_property(node, "scale", base, duration) \
		.set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)

# ===========================================================================
# DAMAGE NUMBERS  (pooled floating labels)
# ===========================================================================
var _pool: Array[Node] = []

func damage_number(parent: Node, world_pos: Vector2, value: Variant,
		options: Dictionary = {}) -> void:
	if parent == null:
		return
	var n: Node = _pool.pop_back() if not _pool.is_empty() else DamageNumber.new()
	if n.get_parent() != parent:
		if n.get_parent() != null:
			n.get_parent().remove_child(n)
		parent.add_child(n)
	n.global_position = world_pos
	n.play(value, options, Callable(self, "_recycle").bind(n))

func _recycle(n: Node) -> void:
	if is_instance_valid(n):
		if n.get_parent() != null:
			n.get_parent().remove_child(n)
		_pool.append(n)

# ===========================================================================
# SHADER EFFECTS  (self-contained; last effect on a target wins)
# ===========================================================================
func _mat(target: CanvasItem, shader: Shader) -> ShaderMaterial:
	var m := target.material as ShaderMaterial
	if m == null or m.shader != shader:
		m = ShaderMaterial.new()
		m.shader = shader
		target.material = m
	return m

func dissolve(target: CanvasItem, duration: float = 0.5,
		edge_color: Color = Color(1.0, 0.6, 0.15)) -> Tween:
	if target == null:
		return null
	var m := _mat(target, DISSOLVE)
	m.set_shader_parameter("edge_color", edge_color)
	m.set_shader_parameter("progress", 0.0)
	var t := target.create_tween()
	t.tween_method(func(v): m.set_shader_parameter("progress", v), 0.0, 1.0, duration)
	return t

func appear(target: CanvasItem, duration: float = 0.5,
		edge_color: Color = Color(1.0, 0.6, 0.15)) -> Tween:
	if target == null:
		return null
	var m := _mat(target, DISSOLVE)
	m.set_shader_parameter("edge_color", edge_color)
	m.set_shader_parameter("progress", 1.0)
	var t := target.create_tween()
	t.tween_method(func(v): m.set_shader_parameter("progress", v), 1.0, 0.0, duration)
	return t

func outline(target: CanvasItem, color: Color = Color.WHITE,
		width: float = 1.0) -> void:
	if target == null:
		return
	var m := _mat(target, OUTLINE)
	m.set_shader_parameter("outline_color", color)
	m.set_shader_parameter("outline_width", width)

func freeze(target: CanvasItem, to: float = 1.0, duration: float = 0.2,
		ice_color: Color = Color(0.6, 0.85, 1.0)) -> Tween:
	if target == null:
		return null
	var m := _mat(target, FREEZE)
	m.set_shader_parameter("ice_color", ice_color)
	m.set_shader_parameter("amount", 0.0)
	var t := target.create_tween()
	t.tween_method(func(v): m.set_shader_parameter("amount", v), 0.0, to, duration)
	return t

func hologram(target: CanvasItem, amount: float = 1.0,
		holo_color: Color = Color(0.4, 0.8, 1.0)) -> void:
	if target == null:
		return
	var m := _mat(target, HOLOGRAM)
	m.set_shader_parameter("holo_color", holo_color)
	m.set_shader_parameter("amount", amount)

func clear(target: CanvasItem) -> void:
	if target == null:
		return
	if target.material is ShaderMaterial:
		var s := (target.material as ShaderMaterial).shader
		if s == DISSOLVE or s == OUTLINE or s == HIT_FLASH or s == FREEZE or s == HOLOGRAM:
			target.material = null

# ===========================================================================
# helpers
# ===========================================================================
func _pos(sprite: CanvasItem, world_pos: Variant) -> Vector2:
	if world_pos is Vector2:
		return world_pos
	if sprite != null and "global_position" in sprite:
		return sprite.global_position
	return Vector2.ZERO

func _number_parent(sprite: CanvasItem, camera: Camera2D) -> Node:
	if sprite != null and sprite.get_parent() != null:
		return sprite.get_parent()
	if camera != null:
		return camera.get_parent()
	return get_tree().current_scene

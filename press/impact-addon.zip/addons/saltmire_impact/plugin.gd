@tool
extends EditorPlugin
## Registers the `Impact` autoload when enabled, removes it when disabled.
## Guarded so it won't clash if the project already defines it.

const AUTOLOAD_NAME := "Impact"
const AUTOLOAD_PATH := "res://addons/saltmire_impact/impact.gd"

func _enter_tree() -> void:
	if not ProjectSettings.has_setting("autoload/" + AUTOLOAD_NAME):
		add_autoload_singleton(AUTOLOAD_NAME, AUTOLOAD_PATH)

func _exit_tree() -> void:
	if ProjectSettings.has_setting("autoload/" + AUTOLOAD_NAME):
		remove_autoload_singleton(AUTOLOAD_NAME)

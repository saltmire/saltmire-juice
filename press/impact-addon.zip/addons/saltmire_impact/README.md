# Saltmire Impact

**One-call game-feel orchestrator for Godot 4.**
Screen shake, curved hit-stop, flash, pooled damage numbers and sprite shader
effects — combined into tunable *combo* calls. One self-contained autoload,
zero dependencies.

> Part of the Saltmire game-feel family (Juice · Transitions · FX). Impact is
> the paid layer that wires them together so a full hit reads as **one line**.

## Why

Good game feel usually means juggling five systems on every hit: a shake, a
flash, a hit-stop, a floating number, maybe a shader. Impact bundles them into
readable combos you can drop in and tune globally.

```gdscript
# a normal hit — flash + shake + rising number
Impact.hit(enemy_sprite, camera, 12)

# a crit — golden flash, big shake, eased hit-stop freeze, punchy number
await Impact.crit(enemy_sprite, camera, 30)

# death — dissolve the sprite away + heavy shake
Impact.explode(enemy_sprite, camera)

# combo counter — intensity scales with the count
Impact.combo(camera, hits)
```

## Install

1. Copy `addons/saltmire_impact/` into your project's `addons/` folder.
2. **Project → Project Settings → Plugins → enable "Saltmire Impact".**
3. That registers the `Impact` autoload. Done.

## Tuning

Every combo reads from `Impact.cfg` — change it once, globally:

```gdscript
Impact.cfg.shake_crit = 0.9
Impact.cfg.crit_color = Color(1, 0.4, 0.2)
Impact.cfg.hitstop_scale = 0.02   # deeper freeze on crits
```

## PRO hit-stop with a curve

`Impact.hitstop_curve(duration, time_scale, ramp)` holds the freeze, then
**eases** `Engine.time_scale` back to 1.0 instead of snapping — a much weightier
impact. Used automatically by `crit()`.

## Primitives (use them à la carte)

`shake` · `hitstop` · `hitstop_curve` · `flash` · `pop` · `damage_number`
`dissolve` · `appear` · `outline` · `freeze` · `hologram` · `clear`

## Demo

Open the project and run `demo/demo.tscn` — it cycles every combo on a sprite.
Click or press **Space** to skip ahead.

## License

Commercial — see `LICENSE.txt`. One purchase per developer/studio. Use in
unlimited commercial projects; don't resell the plugin itself.

https://saltmire.itch.io

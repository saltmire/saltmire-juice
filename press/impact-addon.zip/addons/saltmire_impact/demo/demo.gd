extends Node2D
## Self-playing showcase: each combo below is a SINGLE call to Impact.
## Click or press Space to jump to the next combo.

@onready var sprite: Sprite2D = $World/Sprite
@onready var camera: Camera2D = $Camera
@onready var label: Label = $UI/Effect
var _i := 0
var _skip := false

const COMBOS := ["hit()", "crit()", "explode()", "combo() x N"]


func _ready() -> void:
	_loop()


func _loop() -> void:
	while true:
		var name: String = COMBOS[_i % COMBOS.size()]
		label.text = "Impact." + name
		Impact.clear(sprite)
		sprite.modulate = Color.WHITE
		sprite.scale = Vector2(0.4, 0.4)
		await _pause(0.4)
		match name:
			"hit()":
				for n in 3:
					Impact.hit(sprite, camera, randi_range(8, 20))
					await _pause(0.45)
			"crit()":
				await Impact.crit(sprite, camera, randi_range(40, 99))
				await _pause(0.6)
			"explode()":
				Impact.explode(sprite, camera, 0.55)
				await _pause(1.0)
				Impact.appear(sprite, 0.5)
				await _pause(0.4)
			"combo() x N":
				for n in range(1, 16):
					Impact.combo(camera, n)
					Impact.pop(sprite, 1.08, 0.1)
					await _pause(0.12)
		await _pause(0.6)
		_i += 1


func _pause(seconds: float) -> void:
	var t := 0.0
	while t < seconds and not _skip:
		await get_tree().process_frame
		t += get_process_delta_time()
	_skip = false


func _unhandled_input(event: InputEvent) -> void:
	if (event is InputEventMouseButton and event.pressed) \
			or (event is InputEventKey and event.pressed and event.keycode == KEY_SPACE):
		_skip = true
